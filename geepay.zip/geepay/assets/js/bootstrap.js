function calculatemean(a,b,c,d,e) {
	var mean=(a+b+c+d+e)/5;
document.write("our mean is")
	// body...
}